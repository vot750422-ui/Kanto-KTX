<?php

require_once __DIR__ . '/Room.php';

class Registration
{
    public function __construct(private PDO $db) {}

    public function priorities(): array
    {
        // Dropdown giữ thứ tự mã; danh sách xét duyệt dùng mức ưu tiên giảm dần.
        return $this->db->query('SELECT * FROM dienuutien ORDER BY MaUuTien')->fetchAll();
    }

    public function hasPending(string $mssv): bool
    {
        $stmt = $this->db->prepare("SELECT 1 FROM dondangky WHERE MSSV = ? AND TrangThai = 'Chờ duyệt' LIMIT 1");
        $stmt->execute([$mssv]);
        return (bool) $stmt->fetchColumn();
    }

    public function studentConflict(string $mssv, string $cccd): ?string
    {
        $stmt = $this->db->prepare('SELECT 1 FROM sinhvien WHERE MSSV = ? LIMIT 1');
        $stmt->execute([$mssv]);
        if ($stmt->fetchColumn()) {
            return 'MSSV đã tồn tại trong hồ sơ sinh viên.';
        }
        $stmt = $this->db->prepare('SELECT 1 FROM sinhvien WHERE CCCD = ? LIMIT 1');
        $stmt->execute([$cccd]);
        return $stmt->fetchColumn() ? 'CCCD đã tồn tại trong hồ sơ sinh viên.' : null;
    }

    public function rooms(string $gender): array
    {
        return (new Room($this->db))->rooms($gender, availableOnly: true);
    }

    public function availableRoom(string $gender, string $roomId): ?array
    {
        return (new Room($this->db))->availableRoom($gender, $roomId);
    }

    public function submit(array $data, string $roomId): string
    {
        if (!is_string($data['Email'] ?? null) || strlen($data['Email']) > 100
            || !filter_var($data['Email'], FILTER_VALIDATE_EMAIL)) {
            throw new DomainException('Vui lòng nhập email hợp lệ để nhận kết quả xét duyệt.', 1);
        }
        // Khóa chung UC02: bảo vệ cả MSSV trùng ở hai phòng khác nhau.
        $lock = $this->db->prepare('SELECT GET_LOCK(?, 10)');
        $lockName = 'kanto_uc02_' . substr(hash('sha256', (string) $this->db->query('SELECT DATABASE()')->fetchColumn()), 0, 32);
        $lock->execute([$lockName]);
        if ((int) $lock->fetchColumn() !== 1) {
            throw new RuntimeException('Hệ thống đang bận. Vui lòng gửi lại sau.');
        }
        try {
            $this->db->exec('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');
            $this->db->beginTransaction();
            $stmt = $this->db->prepare('SELECT MaPhong FROM phong WHERE MaPhong = ? FOR UPDATE');
            $stmt->execute([$roomId]);
            if (!$stmt->fetchColumn()) {
                throw new DomainException('Phòng không hợp lệ. Vui lòng chọn phòng khác.', 2);
            }
            if ($this->hasPending($data['MSSV'])) {
                throw new DomainException('MSSV đã có hồ sơ đang được xử lý.', 1);
            }
            if ($conflict = $this->studentConflict($data['MSSV'], $data['CCCD'])) {
                throw new DomainException($conflict, 1);
            }
            $room = $this->availableRoom($data['GioiTinh'], $roomId);
            if (!$room) {
                throw new DomainException('Phòng bạn chọn vừa hết chỗ. Vui lòng chọn phòng khác.', 2);
            }
            $priority = array_filter($this->priorities(), fn($p) => $p['MaUuTien'] === $data['MaUuTien']);
            if (!$priority) {
                throw new DomainException('Diện ưu tiên không còn hợp lệ. Vui lòng kiểm tra lại.', 1);
            }
            $id = strtoupper(bin2hex(random_bytes(5)));
            $fields = ['MSSV', 'HoTen', 'NgaySinh', 'CCCD', 'GioiTinh', 'QueQuan', 'SDT', 'Email', 'Lop', 'NienKhoa', 'MaUuTien', 'FileMinhChung'];
            $values = [$id];
            foreach ($fields as $field) {
                $values[] = $data[$field] ?? null;
            }
            $values[] = $roomId;
            $stmt = $this->db->prepare('INSERT INTO dondangky (MaDonDangKy, ' . implode(', ', $fields) . ', MaPhong) VALUES (' . implode(', ', array_fill(0, count($values), '?')) . ')');
            $stmt->execute($values);
            $this->db->commit();
            return $id;
        } catch (Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        } finally {
            $release = $this->db->prepare('SELECT RELEASE_LOCK(?)');
            $release->execute([$lockName]);
        }
    }
}
